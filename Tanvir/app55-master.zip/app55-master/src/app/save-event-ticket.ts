export class SaveEventTicket {
}
